export const TOKEN = "6011642932:AAH0_i_P0ScC4mdFY_pgKJ_M_DEPIwMuofU";
export const CHAT_ID = "124233158";