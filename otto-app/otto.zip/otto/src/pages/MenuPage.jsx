import { Menu } from "../components";

const MenuPage = () => {
  return (
    <>
      <Menu />
    </>
  );
};

export default MenuPage;
