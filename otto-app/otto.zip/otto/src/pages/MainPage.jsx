import { MenuList } from "../components";

const MainPage = () => {
  return (
    <>
      <MenuList />
    </>
  );
};

export default MainPage;
