export { default as MainPage } from "./MainPage";
export { default as MenuPage } from "./MenuPage";
