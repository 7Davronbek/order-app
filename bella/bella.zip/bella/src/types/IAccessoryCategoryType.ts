export default interface IAccessoryCategoryType {
    id: number,
    name: string
}