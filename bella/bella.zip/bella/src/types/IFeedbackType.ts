export default interface IFeedbackType {
    name: string,
    phoneNumber: string
}