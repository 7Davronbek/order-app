export default interface ICareerType {
    id: number,
    work_type: string,
    work_time: string,
    salary: number,
    image: string
}
