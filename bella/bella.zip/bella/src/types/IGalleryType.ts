export default interface IGalleryType {
    id: number,
    image: string

}