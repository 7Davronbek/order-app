export default interface IAccessoryTypesType {
    id: number,
    name: string
}