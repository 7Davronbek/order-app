export {default as Navbar} from "@/components/Navbar.tsx"
// export {default as Cursor} from "@/components/Cursor.jsx"
export {default as Footer} from "@/components/Footer.tsx"
export {default as Feedback} from "@/components/Feedback.tsx"
export {default as Map} from "@/components/Map.tsx"
export {default as ScrollToTop} from "@/components/ScrollToTop.tsx"
export {default as Up} from './Up'