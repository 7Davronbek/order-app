// @ts-ignore
export {default as Main} from "@/pages/main/Main.tsx"
// @ts-ignore
export {default as WeddingDress} from "@/pages/wedding-dress/WeddingDress.tsx"
// @ts-ignore
export {default as IndividualTailoringService} from "@/pages/individual-tailoring-service/IndividualTailoringService.tsx"
// @ts-ignore
export {default as FabricsForClothing} from "@/pages/fabrics-for-clothing/FabricsForClothing.tsx"
// @ts-ignore
export {default as AboutUs} from "@/pages/about-us/AboutUs.tsx"
// @ts-ignore
export {default as Vacancy} from "@/pages/vacancy/Vacancy.tsx"
// @ts-ignore
export {default as FeedbackPage} from "@/pages/feedback/FeedbackPage.tsx"