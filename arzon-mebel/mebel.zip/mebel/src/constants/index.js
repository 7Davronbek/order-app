export const TOKEN = "7746548464:AAHDBKqdIPj5MAdGt4uy0B6isKew9oiRyug";
export const CHAT_ID = "-1002405099571";
export const ALL = "Все"