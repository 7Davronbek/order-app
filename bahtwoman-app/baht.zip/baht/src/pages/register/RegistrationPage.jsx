import RegisterPhone from "./components/RegisterPhone";

const RegistrationPhonePage = () => {
  return (
    <>
      <RegisterPhone />
    </>
  );
};

export default RegistrationPhonePage;
