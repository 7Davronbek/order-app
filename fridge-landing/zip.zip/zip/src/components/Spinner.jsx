const Spinner = () => {
  return (
    <div className="Spinner">
        <img src="/images/loader.gif" alt="" />
    </div>
  );
};

export default Spinner;
