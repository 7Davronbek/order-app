export const TOKEN = "5835325607:AAEnOHrv5AreKsGTSEDqUTa-4GkiA1byyXo";
export const CHAT_ID = "236039103";
export const LANGUAGE = "COLDMAKER/LANGuAGE";
